<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelevantFigure extends Model
{
    //
    protected $table = 'relevant_figures';
}
