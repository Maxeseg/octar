<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EndPoint extends Model
{
    //
    protected $table = 'end_points';
}
