<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Arm extends Model
{
    //
    protected $table = 'arms';
}
