<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrailType extends Model
{
    //
    protected $table = 'study_type_trails';
}
