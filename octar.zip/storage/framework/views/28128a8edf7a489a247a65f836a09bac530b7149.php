<?php $__env->startSection('title','Octar l Home'); ?>
<?php $__env->startSection('page_container',''); ?>
<?php $__env->startSection('page_content','page-content'); ?>
<?php $__env->startSection('sidebar'); ?>
    <div class="page-sidebar page-sidebar">
        <h1>OCTAR</h1>
        <h3>WELCOME <span><?php echo e(Auth::user()->name); ?></span></h3>
        <div class="ofc-img">
            <img src="<?php echo e(asset('assets/')); ?>/img/ofc.png"  class="img-responsive">
        </div>
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <h4><a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                   class="lg-out"><i class="out"></i> Sign out</a></h4>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="row trials">
            <div class="col-md-10 col-sm-12 col-xs-12">
                <h3><a href="<?php echo e(route('home.create')); ?>" class="btn btn-custom-3"><span>+</span> Add new trial</a></h3>
                <div class="clearfix"></div>
                <div class="all-trials">
                    <?php $__currentLoopData = $trails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="trial">
                            <a href="<?php echo e(url('/home/'.$trail->id)); ?>">
                                <h4><?php echo e($trail->name); ?></h4>
                                <p>By: <?php echo e(auth()->user()->name); ?></p>
                                <p><?php echo e($trail->created_at->format('d/m/Y')); ?></p>
                            </a>
                            <div class="links">
                                <a href="<?php echo e(route('home.edit',$trail->id)); ?>" class="edit"><img src="<?php echo e(asset("assets/")); ?>/img/edit.png"></a>
                                <form action="<?php echo e(route('home.delete',$trail->id)); ?>" method="POST" id="Form.<?php echo e($trail->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <a href="#squarespaceModal-8"  data-toggle="modal" class="delet"><img src="<?php echo e(asset("assets/")); ?>/img/delt.png" ></a>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="clearfix"></div>
                <?php echo e($trails->links()); ?>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if(count(auth()->user()->trails) > 0): ?>
<div class="modal fade" id="squarespaceModal-8" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">

                <div class="col-md-12 col-xs-12">
                    <h3 class="log-title">Are your sure that you want to delete this trial?</h3>

                    <form>

                        <div class="col-md-12 col-sm-12 text-center ">
                            <a href="javascript:{}" onclick='document.getElementById("Form.<?php echo e($trail->id); ?>" ).submit();' type="submit" class="btn btn-custom-3 " >Yes</a>
                        </div>
                    </form>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>