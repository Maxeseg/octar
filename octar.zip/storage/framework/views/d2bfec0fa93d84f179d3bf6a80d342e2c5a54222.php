<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet"  href="<?php echo e(asset("assets/")); ?>/css/bootstrap.css"  type="text/css"/>
    <link rel="stylesheet"  href="<?php echo e(asset("assets/")); ?>/css/style.css"  type="text/css"/>
    <link href="<?php echo e(asset("assets/")); ?>/css/font-awesome.css" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

<section class="contents">
    <div class="page-container <?php echo $__env->yieldContent('page_container'); ?>">
             <?php echo $__env->yieldContent('sidebar'); ?>
        <div class="<?php echo $__env->yieldContent('page_content'); ?>">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</section>



<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="<?php echo e(asset('assets/')); ?>/js/bootstrap.js" type="text/jscript" ></script>
<?php echo $__env->yieldContent('js'); ?>
<div class="modal fade" id="squarespaceModal-7" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="col-md-12 col-xs-12">
                    <h3 class="log-title"><?php echo e(Session::get('success')); ?></h3>
                        <div class="col-md-12 col-sm-12 text-center ">
                            <a href="#" type="button" data-dismiss="modal" class="btn btn-custom-3 " >Close</a>
                        </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>


<?php if(Session::has('success')): ?>
    <script>
        $('#squarespaceModal-7').modal('show');
    </script>
<?php endif; ?>

</body>
</html>
