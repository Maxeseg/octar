<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/')); ?>/css/bootstrap-select.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/')); ?>/css/fastselect.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','Octar l Trial'); ?>
<?php $__env->startSection('page_container','new2-page-container'); ?>
<?php $__env->startSection('page_content','page-content2'); ?>

<?php $__env->startSection('sidebar'); ?>
    <div class="page-sidebar3">
        <div class="">
            <h1>OCTAR</h1>
            <h3>WELCOME <span><?php echo e(Auth::user()->name); ?></span></h3>
            <div class="ofc-img">
                <img src="<?php echo e(asset('assets/')); ?>/img/triall.png"  class="img-responsive">
            </div>
        </div>

        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <h4><a href="#" class="lg-out"><i class="out"></i> Sign out</a></h4>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <a href="<?php echo e(route('home')); ?>">
            <p class="trial-p"><i class="fa fa-home"></i> Back to Home</p>
        </a>
        <h3 class="trail-h1"><?php echo e($trail->name); ?></h3>
        <div class="row trials">

            <div class="col-md-11 col-sm-12 col-xs-12">

                <div class="formy frm clearfix">
                    <div class="col-md-12 col-sm-12 col-xs-12 lft">

                        <h6>Trial Acronym: </h6>
                        <p class="blu-txt nw-wdth1"><?php echo e($trail->acronym); ?></p>

                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 lft">
                        <h6>Authors: </h6>
                        <p class="blu-txt nw-wdth1"><?php echo e($trail->authors); ?></p>
                    </div>

                    <div class="clearfix"></div>

                    <div class="clearfix"></div>
                    <div class="col-md-4 col-sm-4 col-xs-12 lft">
                        <label class="wdth3">Year of publication:</label>
                        <p class="blu-txt nw-wdth2"><?php echo e($trail->publication_year); ?></p>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12 lft">
                        <label class="wdth3">Trial Nb:</label>
                        <p class="blu-txt nw-wdth2"><?php echo e($trail->nb); ?></p>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12 lft">
                        <div class="form-group">
                            <p>OCTAR Nb: <?php echo e($trail->octar_nb); ?></p>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group">
                            <label>Trial Category:</label>
                            <span class="blu-txt wdth no-bord"><?php echo e($trail->category); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group">
                            <label>Sub Category:</label>
                            <span class="blu-txt wdth no-bord"><?php echo e($trail->sub_category); ?></span>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group" >
                            <label>Study type:</label>
                            <div class="wdth no-bord">
                                <?php $__currentLoopData = $trail->study_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="fstChoiceItem pdd bluu"><?php echo e($study_type->name); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group">

                        </div>
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group">
                            <label>Blinding:</label>
                            <span class="blu-txt wdth no-bord"><?php echo e($trail->blind->name); ?></span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group">
                            <label>Patient profile:</label>
                            <span class="blu-txt wdth no-bord"><?php echo e($trail->patient_profile); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group">
                            <label>Trial description</label>
                            <span class="blu-txt wdth"><?php echo e($trail->description); ?> </span>

                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <label>Arms</label>
                            <div class="wdth">
                                <?php $__currentLoopData = $trail->arms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label style="text-align:left; font-weight:normal">Arm Nb:</label>
                                <span class="blu-txt wdth no-bord"><?php echo e($arm->nb); ?></span>
                                <div class="clearfix"></div>
                                <label style="text-align:left; font-weight:normal">Arm Name:</label>
                                <span class="blu-txt wdth no-bord"><?php echo e($arm->name); ?></span>
                                <div class="clearfix"></div>
                                <label style="text-align:left; font-weight:normal; width:100%">Description:</label>
                                <span class="blu-txt "><?php echo e($arm->description); ?></span>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft pull-right">
                        <div class="form-group m-t-60">
                            <label id="lbl-wdth">Cross Over</label>
                            <div class="nw-wdth2">
                                <label style="width:85px">
                                    <input type="radio" checked name="randomization" value="Yes" id="randomization_0">
                                    <?php echo e($trail->cross_over); ?></label>
                            </div>

                            <label id="lbl-wdth"> Second randomization</label>
                            <div class="nw-wdth2">
                                <label style="width:85px">
                                    <input type="radio" name="randomization1" checked value="Yes" id="randomization_0">
                                    <?php echo e($trail->second_randomization); ?></label>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <label>Results:</label>
                        <div class="wdth">
                            <label style="text-align:left; font-weight:normal; width:100%"><?php echo e($trail->end_point->name); ?></label>


                            <label style="text-align:left; font-weight:normal; width:100%">End Point Result:</label>
                            <span class="blu-txt "><?php echo e($trail->endpoint_result); ?></span>

                            <label style="text-align:left; font-weight:normal; width:100%">Statistical Significance:</label>
                            <div class="nw-wdth2">
                                <label style="width:85px">
                                    <input type="radio" name="randomization5" checked value="Yes" id="randomization_0">
                                    <?php echo e($trail->statistical_significance); ?></label>
                            </div>
                        </div>
                        <div class="clearfix"></div>


                            <label>Relevant figures:</label>
                        <div class="wdth">

                            <?php $__currentLoopData = $trail->figures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $figure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label style="text-align:left; font-weight:normal; width:100%">Link:</label>
                                <a class="blu-txt " href="<?php echo e($figure->link); ?>">Link</a>

                                <label style="text-align:left; font-weight:normal; width:100%">Description:</label>
                                <span class="blu-txt "><?php echo e($figure->description); ?></span>
                                    <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-5 col-xs-12 lft pull-right">
                        <div class="form-group">
                            <p style="text-align:left">Previous lines / after failure of</p>
                            <span class="blu-txt "><?php echo e($trail->previous_lines); ?></span>
                            <p style="text-align:left">Points of criticism</p>
                            <span class="blu-txt "><?php echo e($trail->points_of_criticism); ?></span>
                            <p style="text-align:left">Link to full text</p>
                            <span class="blu-txt "><?php echo e($trail->link_to_text); ?></span>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        <div class="form-group" >
                            <label>Keywords</label>
                            <div class="wdth no-bord">
                                <?php $__currentLoopData = $trail->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="fstChoiceItem pdd bluu"><?php echo e($keyword->name); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 lft">
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>



                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/')); ?>/js/bootstrap-select.js"></script>
    <script src="<?php echo e(asset('assets/')); ?>/js/fastselect.standalone.js"></script>
    <script src="<?php echo e(asset('assets/')); ?>/js/nested-form.js"></script>
    <script>
        $('.multipleSelect').fastselect();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>